import { useEffect, useMemo, useState } from "react";
import { RefreshCw } from "lucide-react";
import {
  useBusinessSettings,
  useOrders,
  useSetOrderStatus,
  useUpdateOrderItemPickerDetails,
} from "./lib/hooks";
import {
  getAuthToken,
  getDashboardMe,
  logoutDashboard,
} from "./lib/api";
import { TopBar } from "./components/TopBar";
import { OrderCard } from "./components/OrderCard";
import { SkeletonCard } from "./components/Skeleton";
import { Toast } from "./components/Toast";
import { ConfirmReadyModal } from "./components/ConfirmReadyModal";
import { StockPage } from "./components/StockPage";
import { PromotionsPage } from "./components/PromotionsPage";
import { BusinessSettingsPage } from "./components/BusinessSettingsPage";
import { LoginPage } from "./components/LoginPage";

function sortOrders(orders, mode) {
  const time = (o) => (o.created_at ? new Date(o.created_at).getTime() : 0);
  const byOldest = (a, b) => time(a) - time(b);

  if (mode === "pending") {
    const rank = (s) => (s === "preparing" ? 0 : s === "confirmed" ? 1 : 2);

    return [...orders].sort((a, b) => {
      const r = rank(a.status) - rank(b.status);
      if (r !== 0) return r;
      return byOldest(a, b);
    });
  }

  return [...orders].sort(byOldest);
}

function loadPickedMap() {
  try {
    return JSON.parse(localStorage.getItem("picker_picked_map_v1") || "{}");
  } catch {
    return {};
  }
}
function savePickedMap(map) {
  localStorage.setItem("picker_picked_map_v1", JSON.stringify(map));
}

function loadNoteMap() {
  try {
    return JSON.parse(localStorage.getItem("picker_note_map_v1") || "{}");
  } catch {
    return {};
  }
}
function saveNoteMap(map) {
  localStorage.setItem("picker_note_map_v1", JSON.stringify(map));
}

function DashboardApp({ user, onLogout }) {
  const [toast, setToast] = useState(null);
  const [pickedMap, setPickedMap] = useState(loadPickedMap);
  const [noteMap, setNoteMap] = useState(loadNoteMap);
  const [confirm, setConfirm] = useState({ open: false, order: null });
  const [activeTab, setActiveTab] = useState("pending");
  const [stockRefetch, setStockRefetch] = useState(null);
  const [stockIsFetching, setStockIsFetching] = useState(false);
  const [promotionsRefetch, setPromotionsRefetch] = useState(null);
  const [promotionsIsFetching, setPromotionsIsFetching] = useState(false);
  const [settingsRefetch, setSettingsRefetch] = useState(null);
  const [settingsIsFetching, setSettingsIsFetching] = useState(false);

  const registerStockRefetch = (fn) => {
    setStockRefetch(() => fn || null);
  };

  const registerPromotionsRefetch = (fn) => {
    setPromotionsRefetch(() => fn || null);
  };

  const registerSettingsRefetch = (fn) => {
    setSettingsRefetch(() => fn || null);
  };

  const ALL_STATUSES = ["confirmed", "preparing", "ready", "delivering", "completed"];
  const {
    data: orders,
    isLoading,
    isFetching,
    refetch,
    error,
  } = useOrders(ALL_STATUSES);

  const setStatus = useSetOrderStatus();
  const updateItemDetails = useUpdateOrderItemPickerDetails();
  const businessSettings = useBusinessSettings();

  const notify = (kind, message) => setToast({ kind, message });

  const normalized = useMemo(() => {
    const list = orders ?? [];
    return list.map((o) => {
      const perOrder = pickedMap[o.id] || {};
      return {
        ...o,
        items: (o.items || []).map((it) => ({
          ...it,
          picked: Boolean(perOrder[it.id]),
        })),
      };
    });
  }, [orders, pickedMap]);

  const counts = useMemo(() => {
    const list = normalized ?? [];
    return {
      pending: list.filter(
        (o) => o.status === "confirmed" || o.status === "preparing",
      ).length,
      ready: list.filter((o) => o.status === "ready").length,
      delivering: list.filter((o) => o.status === "delivering").length,
      completed: list.filter((o) => o.status === "completed").length,
    };
  }, [normalized]);

  const visibleOrders = useMemo(() => {
    if (activeTab === "stock" || activeTab === "promotions" || activeTab === "settings") return [];

    let base = normalized;

    if (activeTab === "pending") {
      base = normalized.filter(
        (o) => o.status === "confirmed" || o.status === "preparing",
      );
      return sortOrders(base, "pending");
    }

    if (activeTab === "ready") {
      base = normalized.filter((o) => o.status === "ready");
      return sortOrders(base, "ready");
    }

    if (activeTab === "delivering") {
      base = normalized.filter((o) => o.status === "delivering");
      return sortOrders(base, "delivering");
    }

    if (activeTab === "completed") {
      base = normalized.filter((o) => o.status === "completed");
      return sortOrders(base, "completed");
    }

    return base;
  }, [normalized, activeTab]);

  const busyOrderId = setStatus.isPending
    ? (setStatus.variables?.orderId ?? null)
    : null;

  const busyItemId = updateItemDetails.isPending
    ? (updateItemDetails.variables?.itemId ?? null)
    : null;

  async function onStartPicking(order) {
    try {
      if (order.status !== "confirmed") return;
      await setStatus.mutateAsync({ orderId: order.id, status: "preparing" });
      notify("success", `התחלת ליקוט להזמנה #${order.id}`);
    } catch (e) {
      notify("error", e?.message || "שגיאה בהתחלת ליקוט");
    }
  }

  function requestMarkReady(order) {
    if (order.status !== "preparing") return;
    const note = (noteMap[order.id] ?? order.picker_note ?? "").trim();
    setConfirm({ open: true, order: { ...order, __note: note } });
  }

  async function onShipOrder(order) {
    if (order.status !== "ready" || order.fulfillment_method !== "delivery") return;

    const ok = window.confirm(`לסמן את הזמנה #${order.id} כנשלחה?`);
    if (!ok) return;

    try {
      await setStatus.mutateAsync({ orderId: order.id, status: "delivering" });
      notify("success", `הזמנה #${order.id} סומנה כנשלחה`);
    } catch (e) {
      notify("error", e?.message || "שגיאה בסימון הזמנה כנשלחה");
    }
  }

  async function onCompleteOrder(order) {
    const isDelivery = order.fulfillment_method === "delivery";
    const requiredStatus = isDelivery ? "delivering" : "ready";
    if (order.status !== requiredStatus) return;

    const label = isDelivery ? "כנמסרה" : "כנאספה";
    const ok = window.confirm(`לסמן את הזמנה #${order.id} ${label}?`);
    if (!ok) return;

    try {
      await setStatus.mutateAsync({ orderId: order.id, status: "completed" });
      notify("success", `הזמנה #${order.id} סומנה ${label}`);
    } catch (e) {
      notify("error", e?.message || "שגיאה בסימון סיום הזמנה");
    }
  }

  async function onUpdateItemDetails(order, itemId, details) {
    try {
      await updateItemDetails.mutateAsync({
        orderId: order.id,
        itemId,
        suppliedAmount: details.suppliedAmount,
        pickerNote: details.pickerNote,
      });
    } catch (e) {
      notify("error", e?.message || "שגיאה בשמירת פרטי מוצר");
      throw e;
    }
  }

  async function confirmMarkReady() {
    const order = confirm.order;
    if (!order) return;

    try {
      const hasLocal = Object.prototype.hasOwnProperty.call(noteMap, order.id);
      const pickerNote = hasLocal
        ? (noteMap[order.id] || "").trim()
        : undefined;

      await setStatus.mutateAsync({
        orderId: order.id,
        status: "ready",
        pickerNote,
      });

      setConfirm({ open: false, order: null });

      setPickedMap((prev) => {
        const next = { ...prev };
        delete next[order.id];
        savePickedMap(next);
        return next;
      });

      setNoteMap((prev) => {
        const next = { ...prev };
        delete next[order.id];
        saveNoteMap(next);
        return next;
      });

      notify("success", `הזמנה #${order.id} סומנה כמוכנה`);
    } catch (e) {
      notify("error", e?.message || "שגיאה בסימון הזמנה כמוכנה");
    }
  }

  async function onToggleItem(order, orderItemId, picked) {
    setPickedMap((prev) => {
      const next = { ...prev };
      const perOrder = { ...(next[order.id] || {}) };
      if (picked) perOrder[orderItemId] = true;
      else delete perOrder[orderItemId];
      next[order.id] = perOrder;
      savePickedMap(next);
      return next;
    });

    try {
      if (picked && order.status === "confirmed") {
        await setStatus.mutateAsync({ orderId: order.id, status: "preparing" });
      }
    } catch (e) {
      notify("error", e?.message || "שגיאה בעדכון סטטוס");
    }
  }

  const emptyText =
    activeTab === "pending"
      ? "אין הזמנות לליקוט כרגע"
      : activeTab === "ready"
        ? "אין הזמנות מוכנות כרגע"
        : activeTab === "delivering"
        ? "אין משלוחים בדרך כרגע"
        : activeTab === "completed"
          ? "אין הזמנות שהסתיימו כרגע"
          : "בקרוב…";

  return (
    <div className="min-h-screen">
      <div className="mx-auto max-w-5xl px-4 py-6 sm:py-10">
        <TopBar
          activeTab={activeTab}
          onTabChange={setActiveTab}
          counts={counts}
          user={user}
          onLogout={onLogout}
          shopInfo={businessSettings.data?.info}
          onRefresh={() => {
            if (activeTab === "stock") stockRefetch?.();
            else if (activeTab === "promotions") promotionsRefetch?.();
            else if (activeTab === "settings") settingsRefetch?.();
            else refetch();
          }}
          isRefreshing={
            activeTab === "stock"
              ? stockIsFetching
              : activeTab === "promotions"
                ? promotionsIsFetching
                : activeTab === "settings"
                  ? settingsIsFetching
                  : isFetching
          }
        />

        {error && activeTab !== "stock" && activeTab !== "promotions" && activeTab !== "settings" ? (
          <div className="mt-4 rounded-2xl border border-rose-100 bg-rose-50 p-4 text-sm text-rose-900">
            <div className="font-extrabold">שגיאה בטעינת הזמנות</div>
            <div className="mt-1">{String(error.message || "")}</div>
            {error.details ? (
              <details className="mt-3">
                <summary className="cursor-pointer text-xs font-semibold">
                  פרטים טכניים
                </summary>
                <pre className="mt-2 max-h-48 overflow-auto rounded-xl border border-rose-100 bg-white p-3 text-[11px] leading-5 text-slate-800">
                  {String(error.details)}
                </pre>
              </details>
            ) : null}
            <div className="mt-3">
              <button className="btn-outline" onClick={() => refetch()}>
                נסה שוב
              </button>
            </div>
          </div>
        ) : null}

        {activeTab === "stock" ? (
          <StockPage
            onNotify={(kind, msg) => notify(kind, msg)}
            onOrdersChanged={() => refetch()}
            onRegisterRefetch={registerStockRefetch}
            onFetchingChange={setStockIsFetching}
          />
        ) : activeTab === "promotions" ? (
          <PromotionsPage
            onNotify={(kind, msg) => notify(kind, msg)}
            onRegisterRefetch={registerPromotionsRefetch}
            onFetchingChange={setPromotionsIsFetching}
          />
        ) : activeTab === "settings" ? (
          <BusinessSettingsPage
            onNotify={(kind, msg) => notify(kind, msg)}
            onRegisterRefetch={registerSettingsRefetch}
            onFetchingChange={setSettingsIsFetching}
          />
        ) : (
          <div className="mt-6 grid gap-5">
            {isLoading ? (
              <>
                <SkeletonCard />
                <SkeletonCard />
              </>
            ) : visibleOrders.length ? (
              visibleOrders.map((order) => (
                <OrderCard
                  key={order.id}
                  order={order}
                  busyOrderId={busyOrderId}
                  busyItemId={busyItemId}
                  onStartPicking={() => onStartPicking(order)}
                  onMarkReady={() => requestMarkReady(order)}
                  onMarkShipped={() => onShipOrder(order)}
                  onMarkCompleted={() => onCompleteOrder(order)}
                  onToggleItem={(orderItemId, picked) =>
                    onToggleItem(order, orderItemId, picked)
                  }
                  onUpdateItemDetails={(itemId, details) =>
                    onUpdateItemDetails(order, itemId, details)
                  }
                  shopInfo={businessSettings.data?.info}
                  pickerNote={
                    order.status === "confirmed" || order.status === "preparing"
                      ? (noteMap[order.id] ?? order.picker_note ?? "")
                      : (order.picker_note ?? "")
                  }
                  onChangeNote={(txt) => {
                    setNoteMap((prev) => {
                      const next = { ...prev, [order.id]: txt };
                      saveNoteMap(next);
                      return next;
                    });
                  }}
                />
              ))
            ) : (
              <div className="card p-8 text-center">
                <div className="text-lg font-extrabold">{emptyText}</div>
              </div>
            )}
          </div>
        )}

        <div className="mt-10 text-center text-xs text-slate-500">
          powered by{" "}
          <span className="font-semibold text-slate-700">gogobuy.ai</span>
        </div>
      </div>

      {toast ? (
        <Toast
          kind={toast.kind}
          message={toast.message}
          onClose={() => setToast(null)}
        />
      ) : null}

      <ConfirmReadyModal
        open={confirm.open}
        order={confirm.order}
        note={confirm.order?.__note || ""}
        busy={Boolean(busyOrderId)}
        onCancel={() => setConfirm({ open: false, order: null })}
        onConfirm={confirmMarkReady}
        onChangeNote={(txt) => {
          const id = confirm.order?.id;
          if (!id) return;
          setConfirm((prev) => ({
            ...prev,
            order: prev.order ? { ...prev.order, __note: txt } : prev.order,
          }));
          setNoteMap((prev) => {
            const next = { ...prev, [id]: txt };
            saveNoteMap(next);
            return next;
          });
        }}
      />
    </div>
  );
}

export default function App() {
  const [authState, setAuthState] = useState({ checking: true, user: null });

  useEffect(() => {
    let alive = true;

    async function bootstrap() {
      if (!getAuthToken()) {
        if (alive) setAuthState({ checking: false, user: null });
        return;
      }

      try {
        const res = await getDashboardMe();
        if (alive) setAuthState({ checking: false, user: res.user || null });
      } catch {
        if (alive) setAuthState({ checking: false, user: null });
      }
    }

    bootstrap();

    const onExpired = () => setAuthState({ checking: false, user: null });
    window.addEventListener("dashboard-auth-expired", onExpired);
    return () => {
      alive = false;
      window.removeEventListener("dashboard-auth-expired", onExpired);
    };
  }, []);

  function handleLogout() {
    logoutDashboard();
    setAuthState({ checking: false, user: null });
  }

  if (authState.checking) {
    return (
      <div className="min-h-screen bg-slate-50 px-4 py-8">
        <div className="mx-auto flex min-h-[calc(100vh-4rem)] max-w-md items-center justify-center text-slate-600">
          <div className="card flex items-center gap-3 p-5 text-sm font-semibold">
            <RefreshCw className="h-4 w-4 animate-spin" />
            בודק התחברות…
          </div>
        </div>
      </div>
    );
  }

  if (!authState.user) {
    return <LoginPage onLogin={(user) => setAuthState({ checking: false, user })} />;
  }

  return <DashboardApp user={authState.user} onLogout={handleLogout} />;
}
